﻿namespace baiTap23_10
{
    internal class SanPham
    {
        public string? MaSP { get; set; }
        public string? TenSP { get; set; }
        public decimal DonGia { get; set; }
        public string? HinhAnh { get; set; }
        public string? MoTaNgan { get; set; }
        public string? MoTaChiTiet { get; set; }
        public string? LoaiSP { get; set; }

    }
}